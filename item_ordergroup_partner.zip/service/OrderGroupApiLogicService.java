package com.koreait.day3.service;

import com.koreait.day3.ifs.CrudInterface;
import com.koreait.day3.model.entity.OrderGroup;
import com.koreait.day3.model.enumclass.OrderType;
import com.koreait.day3.model.network.Header;
import com.koreait.day3.model.network.request.OrderGroupApiRequest;
import com.koreait.day3.model.network.response.OrderGroupApiResponse;
import com.koreait.day3.repository.OrderGroupRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service // 서비스레이어, 내부에서 자바로직을 처리함
@RequiredArgsConstructor
public class OrderGroupApiLogicService implements CrudInterface<OrderGroupApiRequest, OrderGroupApiResponse>{

    private final OrderGroupRepository orderGroupRepository;

    @Override
    public Header<OrderGroupApiResponse> create(Header<OrderGroupApiRequest> request) {

        OrderGroupApiRequest orderGroupApiRequest = request.getData();

        OrderGroup orderGroup = OrderGroup.builder()
                .orderAt(orderGroupApiRequest.getOrderAt())
                .orderType(OrderType.ALL)
                .arrivalDate(orderGroupApiRequest.getArrivalDate())
                .paymentType(orderGroupApiRequest.getPaymentType())
                .revAddress(orderGroupApiRequest.getRevAddress())
                .revName(orderGroupApiRequest.getRevName())
                .status(orderGroupApiRequest.getStatus())
                .regDate(orderGroupApiRequest.getRegDate())
                .totalQuentity(orderGroupApiRequest.getTotalQuentity())
                .totalPrice(orderGroupApiRequest.getTotalPrice())
                .build();
        OrderGroup newOderGroup = orderGroupRepository.save(orderGroup);
        return response(newOderGroup);
    }

    @Override
    public Header<OrderGroupApiResponse> read(Long id) {
        return orderGroupRepository.findById(id)
                .map(orderGroup -> response(orderGroup))
                .orElseGet(
                        () -> Header.ERROR("데이터 없음")
                );
    }

    @Override
    public Header<OrderGroupApiResponse> update(Header<OrderGroupApiRequest> request) {
        OrderGroupApiRequest orderGroupApiRequest = request.getData();
        Optional<OrderGroup> optional = orderGroupRepository.findById(orderGroupApiRequest.getId());

        return optional.map(orderGroup -> {
                    orderGroup.setOrderAt(orderGroupApiRequest.getOrderAt());
                    orderGroup.setArrivalDate(orderGroupApiRequest.getArrivalDate());
                    orderGroup.setPaymentType(orderGroupApiRequest.getPaymentType());
                    orderGroup.setRevAddress(orderGroupApiRequest.getRevAddress());
                    orderGroup.setRevName(orderGroupApiRequest.getRevName());
                    orderGroup.setStatus(orderGroupApiRequest.getStatus());
                    orderGroup.setRegDate(orderGroupApiRequest.getRegDate());
                    orderGroup.setTotalQuentity(orderGroupApiRequest.getTotalQuentity());
                    orderGroup.setTotalPrice(orderGroupApiRequest.getTotalPrice());
                    return orderGroup;
        }).map(orderGroup -> orderGroupRepository.save(orderGroup))
                .map(orderGroup -> response(orderGroup))
                .orElseGet(() -> Header.ERROR("데이터 없음"));
    }

    @Override
    public Header delete(Long id) {
        Optional<OrderGroup> optional = orderGroupRepository.findById(id);
        return optional.map(orderGroup -> {
            orderGroupRepository.delete(orderGroup);
            return Header.OK();
        }).orElseGet(() -> Header.ERROR("데이터 없음"));

    }
    private Header<OrderGroupApiResponse> response(OrderGroup orderGroup){
        OrderGroupApiResponse userApiResponse = OrderGroupApiResponse.builder()
                .id(orderGroup.getId())
                .orderAt(orderGroup.getOrderAt())
                .orderType(OrderType.ALL)
                .arrivalDate(orderGroup.getArrivalDate())
                .paymentType(orderGroup.getPaymentType())
                .revAddress(orderGroup.getRevAddress())
                .revName(orderGroup.getRevName())
                .status(orderGroup.getStatus())
                .regDate(orderGroup.getRegDate())
                .totalPrice(orderGroup.getTotalPrice())
                .build();
        return Header.OK(userApiResponse);
    }
}
